<?php
// Text
$_['text_currency'] = 'Валюта';

// Error
$_['error_currency'] = 'Попередження: валюта недоступна!';