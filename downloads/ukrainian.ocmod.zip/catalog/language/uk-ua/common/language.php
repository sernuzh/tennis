<?php
// Text
$_['text_language'] = 'Мова';

// Error
$_['error_language'] = 'Попередження: мова недоступна!';