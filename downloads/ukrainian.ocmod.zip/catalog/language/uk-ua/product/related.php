<?php
$_['text_related'] = 'Інші товари';
