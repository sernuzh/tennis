<?php
// Heading
$_['heading_title'] = 'Бонусні бали';

// Column
$_['column_date_added'] = 'Додано';
$_['column_description'] = 'Опис';
$_['column_points'] = 'Бонусні бали';

// Text
$_['text_account'] = 'Особистий кабінет';
$_['text_reward'] = 'Бонусні бали';
$_['text_total'] = 'Накопичено бонусні бали';
$_['text_no_results'] = 'У Вас немає балів!';