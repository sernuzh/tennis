<?php
// Heading
$_['heading_title'] = 'Підписка на новини';

// Text
$_['text_account'] = 'Особистий кабінет';
$_['text_newsletter'] = 'Розсилка';
$_['text_success'] = 'Ваша підписка успішно оновлена!';

// Entry
$_['entry_newsletter'] = 'Підписатися';