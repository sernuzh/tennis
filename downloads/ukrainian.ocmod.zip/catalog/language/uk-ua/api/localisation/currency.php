<?php
// Text
$_['text_success'] = 'Валюта успішно змінена!';

// Error
$_['error_currency'] = 'Увага: Валюта не знайдена!';