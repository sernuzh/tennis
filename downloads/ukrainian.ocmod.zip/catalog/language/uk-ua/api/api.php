<?php
// Error
$_['error_call'] = 'Виклик API не знайдено';