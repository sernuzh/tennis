<?php
// Text
$_['text_handling'] = 'Оплата за обробку замовлення';