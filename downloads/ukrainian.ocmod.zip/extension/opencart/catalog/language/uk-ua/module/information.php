<?php
// Heading
$_['heading_title'] = 'Інформація';

// Text
$_['text_contact'] = 'Контакти';
$_['text_sitemap'] = 'Карта сайту';