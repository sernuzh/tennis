<?php
// Heading
$_['heading_title'] = 'Доставка в залежності від ваги';

// Text
$_['text_weight'] = 'Вага:';