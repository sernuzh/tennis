<?php
// Heading
$_['heading_title'] = 'Безкоштовна доставка';

// Text
$_['text_description'] = 'Безкоштовна доставка';