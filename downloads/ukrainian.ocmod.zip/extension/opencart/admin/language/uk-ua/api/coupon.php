<?php
// Text
$_['text_coupon']  = 'Купон';

// Entry
$_['entry_coupon'] = 'Купон';
