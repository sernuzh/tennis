<?php
// Heading
$_['heading_title'] = 'Оплата';

// Text
$_['text_success'] = 'Налаштування успішно змінено!';
$_['text_list'] = 'Список способів оплати';

// Column
$_['column_name'] = 'Спосіб оплати';
$_['column_vendor'] = 'Розробник';
$_['column_status'] = 'Статус';
$_['column_sort_order'] = 'Порядок сортування';
$_['column_action'] = 'Дія';

// Error
$_['error_permission'] = 'У Вас немає прав для редагування розширення Оплата!';
$_['error_extension'] = 'Увага: Розширення не існує!';