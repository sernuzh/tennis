<?php
// Heading
$_['heading_title'] = 'Маркетплейси';

// Text
$_['text_success'] = 'Успіх: Ви модифікували маркетплейси!';
$_['text_list'] = 'Список маркетплейсів';

// Column
$_['column_name'] = 'Назва майданчика';
$_['column_status'] = 'Статус';
$_['column_action'] = 'Дія';

// Error
$_['error_permission'] = 'Попередження: Ви не маєте дозволу на модифікацію маркетплейсів!';
$_['error_extension'] = 'Попередження: Розширення не існує!';