<?php
// Heading
$_['heading_title'] = 'Розширення';

// Text
$_['text_success'] = 'Налаштування успішно змінено!';
$_['text_list'] = 'Список розширень <a href="https://opencartbot.com/modules/opencart4/" target="_blank" class="float-end d-none d-sm-block"><kbd style="font-size:0.8rem;font-family:inherit;">Магазин модулів <i class="fas fa-external-link-alt"></i><kbd></a>';
$_['text_type'] = 'Виберіть тип розширення';
$_['text_filter'] = 'Фільтр';